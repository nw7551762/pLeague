from flask import Flask, Response, render_template, jsonify, make_response
import requests
import json
import crawl

app = Flask(__name__)
app.static_folder = 'static'  # 设置静态文件目录为static


@app.route('/')
def index():
    return render_template('threePoint.html')


@app.route('/get-player-stats')
def get_player_stats():
    # 将字典转换为json字符串，并且编码格式设为'utf-8'
    players_json = json.dumps(crawl.get_player_stats(),
                              ensure_ascii=False).encode('utf-8')
    # 使用make_response()方法生成Response对象
    response = make_response(players_json)
    # 设置响应头的Content-Type字段为application/json
    response.headers['Content-Type'] = 'application/json'
    return response


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8000)
